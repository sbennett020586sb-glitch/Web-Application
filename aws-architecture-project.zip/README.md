# AWS Architecture Project: Web Application

This project demonstrates a simple web application architecture on AWS using:

- EC2 for web server
- RDS (MySQL) for database
- S3 for static assets
- Elastic Load Balancer for traffic distribution
- Route 53 for DNS
- CloudFront for CDN (optional)

## Project Structure

aws-architecture-project/
│
├── app/                  # Flask web app
├── diagram/              # Architecture diagram
├── README.md
└── LICENSE

## Deployment Steps

1. Create VPC with public/private subnets
2. Launch EC2 instances in public subnet
3. Deploy Flask app on EC2
4. Create RDS MySQL in private subnet
5. Set up Security Groups for EC2 & RDS
6. Set up Elastic Load Balancer to distribute traffic
7. Upload static assets to S3
8. Optional: Use CloudFront for CDN and Route 53 for custom domain

## Author

Your Name – AWS Beginner
